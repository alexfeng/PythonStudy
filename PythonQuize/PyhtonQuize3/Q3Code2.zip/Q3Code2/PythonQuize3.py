import requests
from bs4 import BeautifulSoup
from pypinyin import lazy_pinyin
from requests.exceptions import RequestException
import os
import csv
from lxml import html

etree = html.etree

# 获取当前目录
currentPath = os.getcwd()
# 输入当前路径
# 打开文件，传入文件名和标识符，r代表读
filepath = currentPath + '/data/user_data.csv'


def myInput():
    #输入城市名称查询
    city = input('请输入你想要查询天气的城市：')
    # city = sys.stdin.readline()
    pinyin_city = lazy_pinyin(city)
    return pinyin_city[0] + pinyin_city[1]


class TianQiSpider:
    """docstring for TianQiSpider"""

    def __init__(self, name):
        self.name = name
        self.url = 'http://www.tianqi.com/' + name + '/'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'
        }

    def get_html(self):
        try:
            response = requests.get(self.url, headers=self.headers)
            if response.status_code == requests.codes.OK:
                return response.text
            else:
                return None
        except RequestException:
            return None

    def get_info(self, html):
        #打开文件
        fp = open(filepath, 'wt', newline='', encoding='UTF-8')
        #文件写入天气数据
        writer = csv.writer(fp)
        writer.writerow(['日期', '星期几', '天气', '温度区间', '风向'])
        soup = BeautifulSoup(html, 'lxml')
        selector = etree.HTML(html)
        days = soup.select('div.day7 > ul.week > li > b')
        xingqijis = soup.select('div.day7 > ul.week > li > span')
        tianqis = selector.xpath('//div[@class="day7"]/ul[2]/li/text()')
        temp_froms = selector.xpath('//div[@class="zxt_shuju"]/ul/li/b/text()')
        temp_tos = selector.xpath(
            '//div[@class="zxt_shuju"]/ul/li/span/text()')
        winds = selector.xpath('//ul[@class="txt"]/li/text()')
        for day, xingqiji, tianqi, temp_from, temp_to, wind in zip(days, xingqijis, tianqis, temp_froms, temp_tos,
                                                                   winds):
            日期 = day.get_text()
            星期 = xingqiji.get_text()
            天气 = tianqi
            温度区间 = temp_from + '~' + temp_to
            风 = wind
            writer.writerow([日期, 星期, 天气, 温度区间, 风])
        fp.close()

    def get_return(self):
        print("天气查询成功！")
        print("天气生产路径：" + filepath)

    def run(self):
        html = self.get_html()
        self.get_info(html)
        self.get_return()


if __name__ == '__main__':
    city = myInput()
    tianqi_spider = TianQiSpider(city)
    tianqi_spider.run()
