//
//  HelpTool.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/11.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Masonry/Masonry.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import "AFNetworking.h"
#import <SVProgressHUD/SVProgressHUD.h>
#import <JSONModel/JSONModel.h>
NS_ASSUME_NONNULL_BEGIN

#define RGB16(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define WS(weakSelf) __weak __typeof(&*self) weakSelf = self;

#define IPAdress @"ipadressKey"

@interface HelpTool : NSObject



@end

NS_ASSUME_NONNULL_END
