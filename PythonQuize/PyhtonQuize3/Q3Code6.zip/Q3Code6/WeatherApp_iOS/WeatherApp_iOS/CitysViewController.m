//
//  CitysViewController.m
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/12.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import "CitysViewController.h"
#import "ProvinceModel.h"
#import "CityModel.h"
#import "CityweatherInfo.h"
#import "WeatherViewController.h"
@interface CitysViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)NSInteger    currentSeletedProvinceIndex;
@property(nonatomic,strong)NSMutableArray *citysArray;
@end

@implementation CitysViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"省市信息";
    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    self.citysArray = [[NSMutableArray alloc]init];
    self.tableView = [[UITableView alloc]init];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.backgroundColor=[UIColor clearColor];
    self.tableView.backgroundView = nil;
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString *cellidfer=@"PhotoAlbumCircleNoDatasTableViewCell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellidfer];
    if(cell==nil){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidfer];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    CityModel *model =[self.citysArray objectAtIndex:indexPath.row];
    cell.textLabel.font=[UIFont systemFontOfSize:14];
    cell.textLabel.textColor=[UIColor whiteColor];
    cell.textLabel.text=model.city_name;
    cell.backgroundColor=RGB16(0xFF2D2D);
    
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == self.currentSeletedProvinceIndex){
        return self.citysArray.count;
    }
    return 0;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.provicesArray.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view =[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 30)];
    view.layer.borderWidth=0.5;
    view.layer.backgroundColor=RGB16(0x8c8c8c).CGColor;
    view.backgroundColor=RGB16(0x01847f);
    UILabel *lable =[[UILabel alloc]initWithFrame:CGRectMake(15, 0,self.view.bounds.size.width-15, 30)];
    lable.backgroundColor=[UIColor clearColor];
    lable.font=[UIFont systemFontOfSize:14];
    lable.textColor=[UIColor whiteColor];
    ProvinceModel *province = [self.provicesArray objectAtIndex: section];
    lable.text=province.province_name;
    [view addSubview:lable];
    lable.tag = section;
    lable.userInteractionEnabled=YES;
    UITapGestureRecognizer *tap =[[UITapGestureRecognizer alloc]init];
    [lable addGestureRecognizer:tap];
    @weakify(self);
    [[tap rac_gestureSignal]subscribeNext:^(__kindof UIGestureRecognizer * _Nullable x) {
        @strongify(self);
        UIView * aview = x.view;
        [self requestTargetCitysWithProvince_index:aview.tag];
    }];
    return view;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CityModel *model =[self.citysArray objectAtIndex:indexPath.row];
    if(model.city_name.length>0){
        [self requestWeatherInfoWithCity_name:model.city_name];
    }
}

-(void)requestTargetCitysWithProvince_index:(NSInteger)province_index{
    [SVProgressHUD show];
    ProvinceModel *province = [self.provicesArray objectAtIndex: province_index];
    NSUserDefaults *userDefautl=[NSUserDefaults standardUserDefaults];
    NSString *ipstr = [userDefautl objectForKey: IPAdress];
    if(ipstr.length==0){
        [SVProgressHUD dismiss];
        [SVProgressHUD showErrorWithStatus:@"没有ip地址"];
        [SVProgressHUD dismissWithDelay:3];
        return;
    }
    else{
        AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
        [SVProgressHUD show];
        WS(weakSelf);
        NSString *url =[NSString stringWithFormat:@"http://%@/weather/province/%@/",ipstr,province.province_name];
        NSString * encodingString = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [session GET:encodingString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [SVProgressHUD dismiss];
            NSDictionary *data = [responseObject objectForKey:@"data"];
            NSArray *provinces=[data objectForKey:@"citys"];
            NSMutableArray *provinceModelArray=[[NSMutableArray alloc]init];
            for (NSDictionary *dic in provinces) {
                CityModel *model = [[CityModel alloc]initWithDictionary:dic error:nil];
                [provinceModelArray addObject:model];
            }
            if(provinceModelArray.count > 0){
                weakSelf.currentSeletedProvinceIndex = province_index;
                [weakSelf.citysArray removeAllObjects];
                [weakSelf.citysArray addObjectsFromArray:provinceModelArray];
                [weakSelf.tableView reloadData];
                
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"失败");
            [SVProgressHUD dismiss];
            [SVProgressHUD showErrorWithStatus:error.description];
            [SVProgressHUD dismissWithDelay:3];
        }];
    }
}


-(void)requestWeatherInfoWithCity_name:(NSString *)cityName{
    [SVProgressHUD show];
    NSUserDefaults *userDefautl=[NSUserDefaults standardUserDefaults];
    NSString *ipstr = [userDefautl objectForKey: IPAdress];
    if(ipstr.length==0){
        [SVProgressHUD dismiss];
        [SVProgressHUD showErrorWithStatus:@"没有ip地址"];
        [SVProgressHUD dismissWithDelay:3];
        return;
    }
    else{
        AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
        [SVProgressHUD show];
        WS(weakSelf);
        NSString *url =[NSString stringWithFormat:@"http://%@/weather/city/%@/",ipstr,cityName];
        NSString * encodingString = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [session GET:encodingString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [SVProgressHUD dismiss];
            NSDictionary *dic = [responseObject objectForKey:@"data"];
            CityweatherInfo *info = [[CityweatherInfo alloc]initWithDictionary:dic error:nil];
            if(info){
                WeatherViewController *weatherVc = [[WeatherViewController alloc]init];
                weatherVc.weatherInfo = info;
                [weakSelf.navigationController pushViewController:weatherVc animated:YES];
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"失败");
            [SVProgressHUD dismiss];
            [SVProgressHUD showErrorWithStatus:error.description];
            [SVProgressHUD dismissWithDelay:3];
        }];
    }
}
@end
