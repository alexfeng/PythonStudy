//
//  ViewController.m
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/11.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import "ViewController.h"
#import "WeatherViewController.h"
#import "CityweatherInfo.h"
#import "CitysViewController.h"
#import "ProvinceModel.h"
@interface ViewController ()
@property(nonatomic,strong)UITextField *ipField;
@property(nonatomic,strong)UIButton    *ensureBtn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title=@"ip地址";
    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    UILabel * alterLbl = [[UILabel alloc]init];
    [self.view addSubview:alterLbl];
    alterLbl.text=@"请输入ip地址:";
    alterLbl.font=[UIFont systemFontOfSize:14];
    alterLbl.textColor=[UIColor blackColor];
    
    self.ipField = [[UITextField alloc]init];
    [self.view addSubview:self.ipField];
    self.ipField.font=[UIFont systemFontOfSize:14];
    self.ipField.textColor=[UIColor blackColor];
    self.ipField.layer.borderColor=RGB16(0x8c8c8c).CGColor;
    self.ipField.layer.borderWidth=0.5;
    self.ipField.layer.cornerRadius=8;
    self.ipField.layer.masksToBounds=YES;
    self.ipField.placeholder=@"ip地址";
    
    self.ensureBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:self.ensureBtn];
    self.ensureBtn.backgroundColor=RGB16(0x01847f);
    [self.ensureBtn setTitle:@"确定" forState:UIControlStateNormal];
    [self.ensureBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.ensureBtn.titleLabel.font=[UIFont systemFontOfSize:14];
    self.ensureBtn.layer.borderColor=RGB16(0x8c8c8c).CGColor;
    self.ensureBtn.layer.borderWidth=0.5;
    self.ensureBtn.layer.cornerRadius=8;
    self.ensureBtn.layer.masksToBounds=YES;
    
    [self.ensureBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-15);
        make.height.mas_equalTo(@40);
        make.centerY.equalTo(self.view);
        make.width.mas_equalTo(@80);
    }];
    
    [self.ipField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(20);
        make.centerY.equalTo(self.view);
        make.height.mas_equalTo(@40);
        make.right.equalTo(self.ensureBtn.mas_left).offset(-15);
    }];
    
    [alterLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.ipField);
        make.bottom.equalTo(self.ipField.mas_top).offset(-5);
    }];
    
    [[self.ensureBtn rac_signalForControlEvents:UIControlEventTouchUpInside]subscribeNext:^(__kindof UIControl * _Nullable x) {
        if(self.ipField.text.length==0){
            [SVProgressHUD showErrorWithStatus:@"不能为空"];
            return ;
        }
        else{
            [self requestData];
        }
    }];
    NSUserDefaults *userDefautl=[NSUserDefaults standardUserDefaults];
    NSString *ipstr = [userDefautl objectForKey: IPAdress];
    if(ipstr.length>0){
        self.ipField.text = ipstr;
    }
}

-(void)requestData{
    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    [SVProgressHUD show];
    WS(weakSelf);
    NSString *url =[NSString stringWithFormat:@"http://%@/weather/province/",self.ipField.text];
    [session GET:url parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        NSUserDefaults *userDefautl=[NSUserDefaults standardUserDefaults];
        [userDefautl setObject:weakSelf.ipField.text forKey:IPAdress];
        [userDefautl synchronize];
        NSDictionary *data = [responseObject objectForKey:@"data"];
        NSArray *provinces=[data objectForKey:@"provinces"];
        NSMutableArray *provinceModelArray=[[NSMutableArray alloc]init];
        for (NSDictionary *dic in provinces) {
            ProvinceModel *model = [[ProvinceModel alloc]initWithDictionary:dic error:nil];
            [provinceModelArray addObject:model];
        }
        if(provinceModelArray.count > 0){
            CitysViewController *cityVc = [[CitysViewController alloc]init];
            cityVc.provicesArray=provinceModelArray;
            [self.navigationController pushViewController:cityVc animated:YES];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"失败");
        NSUserDefaults *userDefautl=[NSUserDefaults standardUserDefaults];
        [userDefautl setObject:@"" forKey:IPAdress];
        [userDefautl synchronize];
        [SVProgressHUD dismiss];
        [SVProgressHUD showErrorWithStatus:error.description];
        [SVProgressHUD dismissWithDelay:3];
    }];
}

@end
