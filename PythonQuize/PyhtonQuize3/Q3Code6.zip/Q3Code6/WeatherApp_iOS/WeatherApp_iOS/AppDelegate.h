//
//  AppDelegate.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/11.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

