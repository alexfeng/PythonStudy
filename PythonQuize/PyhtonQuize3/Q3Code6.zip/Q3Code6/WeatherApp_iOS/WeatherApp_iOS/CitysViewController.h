//
//  CitysViewController.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/12.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HelpTool.h"
NS_ASSUME_NONNULL_BEGIN

@interface CitysViewController : UIViewController
@property(nonatomic,strong)NSArray *provicesArray;
@end

NS_ASSUME_NONNULL_END
