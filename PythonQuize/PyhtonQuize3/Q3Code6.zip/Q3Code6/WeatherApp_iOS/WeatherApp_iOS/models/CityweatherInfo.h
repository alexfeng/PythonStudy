//
//  CityweatherInfo.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/11.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <JSONModel/JSONModel.h>



@protocol weatherInfo <NSObject>

@end

@interface weatherInfo : JSONModel
@property(nonatomic,strong)NSString *date_time;
@property(nonatomic,strong)NSString *weatherinfo;
@property(nonatomic,strong)NSString *temperature;
@property(nonatomic,strong)NSString *wind;
@property(nonatomic,strong)NSString *wind_level;
@property(nonatomic,strong)NSString *ultraviolet_name;
@property(nonatomic,strong)NSString *Ultraviolet_level;
@property(nonatomic,strong)NSString *Ultraviolet_desc;
@property(nonatomic,strong)NSString *dress_name;
@property(nonatomic,strong)NSString *dress_level;
@property(nonatomic,strong)NSString *dress_desc;
@property(nonatomic,strong)NSString *washcar_name;
@property(nonatomic,strong)NSString *washcar_level;
@property(nonatomic,strong)NSString *washcar_desc;
@property(nonatomic,strong)NSString *airpollution_name;
@property(nonatomic,strong)NSString *airpollution_level;
@property(nonatomic,strong)NSString *airpollution_desc;
@end

@interface CityweatherInfo : JSONModel
@property(nonatomic,strong)NSString *city;
@property(nonatomic,strong)NSArray <weatherInfo,Optional> * weatherInfo_list;
@end


