//
//  CityModel.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/12.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <JSONModel/JSONModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface CityModel : JSONModel
@property(nonatomic,strong)NSString *city_name;
@property(nonatomic,strong)NSString *city_url;
@end

NS_ASSUME_NONNULL_END
