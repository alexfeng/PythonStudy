//
//  ProvinceModel.h
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/12.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import <JSONModel/JSONModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProvinceModel : JSONModel
@property(nonatomic,strong)NSString *province_name;
@property(nonatomic,strong)NSString *province_url;
@end

NS_ASSUME_NONNULL_END
