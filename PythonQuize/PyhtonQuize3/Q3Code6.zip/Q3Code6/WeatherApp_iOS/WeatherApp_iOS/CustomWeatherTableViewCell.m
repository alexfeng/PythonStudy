//
//  CustomWeatherTableViewCell.m
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/12.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import "CustomWeatherTableViewCell.h"
@interface CustomWeatherTableViewCell()
@property(nonatomic,strong)UILabel *dateLbl;
@property(nonatomic,strong)UILabel *weahterLbl;
@property(nonatomic,strong)UILabel *wenduLbl;
@property(nonatomic,strong)UILabel *windLbl;

@property(nonatomic,strong)UILabel *ultravioletLbl;
@property(nonatomic,strong)UILabel *dressLbl;
@property(nonatomic,strong)UILabel *washcarLbl;
@property(nonatomic,strong)UILabel *airpllutionLbl;
@end
@implementation CustomWeatherTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        self.dateLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.dateLbl];
        self.dateLbl.textColor=[UIColor whiteColor];
        self.dateLbl.font=[UIFont systemFontOfSize:15];
        [self.dateLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView);
            make.top.equalTo(self.contentView).offset(15);
            make.height.mas_equalTo(@(30));
        }];
        
        self.weahterLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.weahterLbl];
        self.weahterLbl.textColor=[UIColor whiteColor];
        self.weahterLbl.font=[UIFont systemFontOfSize:15];
        [self.weahterLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.top.equalTo(self.dateLbl.mas_bottom).offset(5);
            make.right.equalTo(self.contentView);
            make.height.mas_equalTo(@(20));
        }];
        
       
        self.wenduLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.wenduLbl];
        self.wenduLbl.textColor=[UIColor whiteColor];
        self.wenduLbl.font=[UIFont systemFontOfSize:15];
        [self.wenduLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView);
            make.top.equalTo(self.weahterLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(20));
        }];
        
        self.windLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.windLbl];
        self.windLbl.textColor=[UIColor whiteColor];
        self.windLbl.font=[UIFont systemFontOfSize:15];
        [self.windLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView);
            make.top.equalTo(self.wenduLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(20));
        }];
        
        self.ultravioletLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.ultravioletLbl];
        self.ultravioletLbl.textColor=[UIColor whiteColor];
        self.ultravioletLbl.font=[UIFont systemFontOfSize:13];
        self.ultravioletLbl.numberOfLines=0;
        self.ultravioletLbl.lineBreakMode = NSLineBreakByWordWrapping;
        [self.ultravioletLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView).offset(-20);
            make.top.equalTo(self.windLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(40));
        }];
        
        self.dressLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.dressLbl];
        self.dressLbl.textColor=[UIColor whiteColor];
        self.dressLbl.font=[UIFont systemFontOfSize:13];
        self.dressLbl.numberOfLines=0;
        self.dressLbl.lineBreakMode = NSLineBreakByWordWrapping;
        [self.dressLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView).offset(-20);
            make.top.equalTo(self.ultravioletLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(40));
        }];
        
        self.washcarLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.washcarLbl];
        self.washcarLbl.textColor=[UIColor whiteColor];
        self.washcarLbl.font=[UIFont systemFontOfSize:13];
        self.washcarLbl.numberOfLines=0;
        self.washcarLbl.lineBreakMode = NSLineBreakByWordWrapping;
        [self.washcarLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView).offset(-20);
            make.top.equalTo(self.dressLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(40));
        }];
        
        self.airpllutionLbl = [[UILabel alloc]init];
        [self.contentView addSubview:self.airpllutionLbl];
        self.airpllutionLbl.textColor=[UIColor whiteColor];
        self.airpllutionLbl.font=[UIFont systemFontOfSize:13];
        self.airpllutionLbl.numberOfLines=0;
        self.airpllutionLbl.lineBreakMode = NSLineBreakByWordWrapping;
        [self.airpllutionLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.contentView).offset(20);
            make.right.equalTo(self.contentView).offset(-20);
            make.top.equalTo(self.washcarLbl.mas_bottom).offset(5);
            make.height.mas_equalTo(@(40));
        }];
        
        
    }
    return self;
}

-(void)setweatherinfo:(weatherInfo *)info{
    self.dateLbl.text = info.date_time;
    self.weahterLbl.text = info.weatherinfo;
    self.wenduLbl.text = info.temperature;
    self.windLbl.text = [NSString stringWithFormat:@"%@    %@",info.wind,info.wind_level];
    self.ultravioletLbl.text = [NSString stringWithFormat:@"%@ : %@\n%@",info.ultraviolet_name,info.Ultraviolet_level,info.Ultraviolet_desc];
    self.dressLbl.text = [NSString stringWithFormat:@"%@ : %@\n%@",info.dress_name,info.dress_level,info.dress_desc];
    self.washcarLbl.text = [NSString stringWithFormat:@"%@ : %@\n%@",info.washcar_name,info.washcar_level,info.washcar_desc];
    self.airpllutionLbl.text = [NSString stringWithFormat:@"%@ : %@\n%@",info.airpollution_name,info.airpollution_level,info.airpollution_desc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
