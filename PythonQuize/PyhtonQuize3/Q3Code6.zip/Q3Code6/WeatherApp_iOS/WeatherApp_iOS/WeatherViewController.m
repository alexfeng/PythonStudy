//
//  WeatherViewController.m
//  WeatherApp_iOS
//
//  Created by 杨国强 on 2019/7/11.
//  Copyright © 2019年 杨国强. All rights reserved.
//

#import "WeatherViewController.h"
#import "CustomWeatherTableViewCell.h"
@interface WeatherViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation WeatherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=[NSString stringWithFormat:@"%@天气信息",self.weatherInfo.city];
    self.view.backgroundColor=[UIColor groupTableViewBackgroundColor];
    self.tableView = [[UITableView alloc]init];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.backgroundColor=[UIColor clearColor];
    self.tableView.backgroundView = nil;
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    static NSString *cellidfer=@"CustomWeatherTableViewCell";
    CustomWeatherTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellidfer];
    if(cell==nil){
        cell = [[CustomWeatherTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidfer];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    if(indexPath.row%2==0){
        cell.backgroundColor=RGB16(0x46A3FF);
    }
    else{
        cell.backgroundColor=RGB16(0x7D7DFF);
    }
    weatherInfo *infomodel = [self.weatherInfo.weatherInfo_list objectAtIndex:indexPath.row];
    [cell setweatherinfo:infomodel];
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.weatherInfo.weatherInfo_list.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 140 + 180;
}


@end
