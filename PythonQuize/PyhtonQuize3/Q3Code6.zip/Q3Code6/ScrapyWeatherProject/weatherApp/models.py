from django.db import models

# Create your models here.
# 省份信息
class Province_info(models.Model):
    province_name = models.CharField('省名', max_length=50)
    province_url = models.CharField('省链接', max_length=100)

    class Meta:
        verbose_name = '省份信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.province_name


# 城市信息
class City_info(models.Model):
    city_name = models.CharField('市名', max_length=50)
    city_url = models.CharField('市链接', max_length=100)
    province = models.ForeignKey(Province_info, on_delete=models.CASCADE, verbose_name='所属省份', blank=True, null=True)

    class Meta:
        verbose_name = '城市信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.city_name


# 天气信息
class weather_info(models.Model):
    date_time = models.CharField('日期', max_length=100)
    weatherinfo = models.CharField('天气情况', max_length=100)
    temperature = models.CharField('气温', max_length=100)
    wind = models.CharField('刮风', max_length=100)
    wind_level = models.CharField('风级', max_length=100)
    city = models.ForeignKey(City_info, on_delete=models.CASCADE, verbose_name='所属省份', blank=True, null=True)
    # 紫外线
    ultraviolet_name = models.CharField('紫外线', max_length=100)
    Ultraviolet_level = models.CharField('强弱', max_length=100)
    Ultraviolet_desc = models.CharField('描述', max_length=300)
    # 穿衣
    dress_name = models.CharField('穿衣', max_length=100)
    dress_level = models.CharField('强弱', max_length=100)
    dress_desc = models.CharField('描述', max_length=300)
    # 洗车
    washcar_name = models.CharField('洗车', max_length=100)
    washcar_level = models.CharField('强弱', max_length=100)
    washcar_desc = models.CharField('描述', max_length=300)
    # 空气污染
    airpollution_name = models.CharField('空气污染', max_length=100)
    airpollution_level = models.CharField('强弱', max_length=100)
    airpollution_desc = models.CharField('描述', max_length=300)

    class Meta:
        verbose_name = '天气信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return "天气情况"