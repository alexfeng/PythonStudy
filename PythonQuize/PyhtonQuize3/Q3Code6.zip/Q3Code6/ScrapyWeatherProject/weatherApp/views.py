from django.shortcuts import render
from django.http import HttpResponse
from weatherApp.models import City_info
from weatherApp.models import Province_info
from weatherApp.models import weather_info
from django.forms.models import model_to_dict
import logging
import json
from django.core.serializers import serialize
# Create your views here.


def default(request):
     objc = weather_info.objects.filter(city__city_name='西安').values('date_time', 'day_weather', 'night_weather', 'temperature', 'wind')
     list1 = list(objc)
     dic = {'city': '西安', 'weatherInfo_list': list1}
     response = {'status': 1, 'message': '请求成功', 'data': dic}
     data = json.dumps(response)
     return HttpResponse(data, content_type="application/json")


def appointedCity(request, city_name='西安'):
    objc = weather_info.objects.filter(city__city_name=city_name).values('date_time', 'weatherinfo', 'temperature',
                                                                    'wind', 'wind_level', 'ultraviolet_name', 'Ultraviolet_level', 'Ultraviolet_desc',
                                                                         'dress_name', 'dress_level', 'dress_desc', 'washcar_name', 'washcar_level',
                                                                         'washcar_desc', 'airpollution_name' ,'airpollution_level', 'airpollution_desc')
    list1 = list(objc)
    if len(list1) > 0:
        dic = {'city': city_name, 'weatherInfo_list': list1}
        response = {'status': 1, 'message': '请求成功', 'data': dic}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")
    else:
        response = {'status': -1, 'message': '没有数据'}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")

def request_allprovince(request):
    object = Province_info.objects.all().values('province_name', 'province_url')
    list1 = list(object)
    if len(list1) > 0:
        dic = {'provinces': list1}
        response = {'status': 1, 'message': '请求成功', 'data': dic}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")
    else:
        response = {'status': -1, 'message': '没有数据'}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")


def requestprovince_citys(request, province_name='陕西'):
    object = City_info.objects.filter(province__province_name=province_name).values('city_name', 'city_url')
    list1 = list(object)
    if len(list1) > 0:
        dic = {'province': province_name, 'citys': list1}
        response = {'status': 1, 'message': '请求成功', 'data': dic}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")
    else:
        response = {'status': -1, 'message': '没有数据'}
        data = json.dumps(response)
        return HttpResponse(data, content_type="application/json")
    pass

