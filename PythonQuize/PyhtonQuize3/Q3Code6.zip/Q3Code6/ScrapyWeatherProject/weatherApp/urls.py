from django.urls import path, re_path
from . import views


urlpatterns = [
    path('', views.default),
    re_path(r'city/(?P<city_name>\S+)/$', views.appointedCity),
    re_path(r'^province/$', views.request_allprovince),
    re_path(r'^province/(?P<province_name>\S+)/$', views.requestprovince_citys)
]