from django.contrib import admin

from weatherApp.models import Province_info
from weatherApp.models import City_info
from weatherApp.models import weather_info

admin.site.register(Province_info)
admin.site.register(City_info)
admin.site.register(weather_info)
