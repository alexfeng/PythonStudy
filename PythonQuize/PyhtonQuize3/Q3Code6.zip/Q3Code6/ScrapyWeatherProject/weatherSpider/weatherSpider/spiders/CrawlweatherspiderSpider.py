# -*- coding: utf-8 -*-
import scrapy
import scrapy
from weatherSpider.items import WeatherProvinceItem
from weatherSpider.items import WeatherCityItem
from weatherSpider.items import WeatherDayStatusItem


class CrawlweatherspiderspiderSpider(scrapy.Spider):
    name = 'weatherSpider'
    allowed_domains = ['weather.com.cn']
    root_url = 'http://www.weather.com.cn'
    start_urls = ['http://www.weather.com.cn/textFC/hb.shtml#']

    def parse(self, response):
        # 获取省份信息
        atags = response.xpath('//div[@class="lqcontentBoxheader"]//a')
        for atag in atags:
            pro_name = atag.xpath('./text()').extract_first()
            pro_url = atag.xpath('./@href').extract_first()
            province_item = WeatherProvinceItem()
            province_item['province_name'] = pro_name
            province_item['province_url'] = pro_url
            yield province_item
            target_province_url = self.root_url + pro_url
            request = scrapy.Request(target_province_url, callback=self.cityParse, dont_filter=True)
            request.meta['province'] = province_item.instance
            yield request

    def cityParse(self, response):
        div = response.xpath('//div[@class="hanml"]/div')[0]
        subdivs = div.xpath('./div[@class="conMidtab3"]')
        for divtag in subdivs:
            tabletag = divtag.xpath('./table')
            tabletag = tabletag[0]
            trs = tabletag.xpath('.//tr')
            tr = trs[0]
            tds = tr.xpath('./td')
            td = tds[1]
            city_name = td.xpath('./a/text()').extract_first()
            city_url = td.xpath('./a/@href').extract_first()
            city_item = WeatherCityItem()
            city_item['city_name'] = city_name
            city_item['city_url'] = city_url
            city_item['province'] = response.meta['province']
            yield city_item
            request = scrapy.Request(city_url, callback=self.weatherParse, dont_filter=True)
            request.meta['city'] = city_item.instance
            yield request

    def weatherParse(self, response):
        lis = response.xpath('//ul[@class="t clearfix"]/li')
        uls = response.xpath('//div[@class="livezs curve_livezs"]//ul')
        print(uls)
        for index, li in enumerate(lis):
            weather_item = WeatherDayStatusItem()
            ul = uls[index]
            date_time = li.xpath('./h1/text()').extract_first()
            weather_item['date_time'] = date_time
            weatherinfo = li.xpath('./p[@class="wea"]/text()').extract_first()
            weather_item['weatherinfo'] = weatherinfo
            temperature1 = li.xpath('./p[@class="tem"]/span/text()').extract_first()
            temperature2 = li.xpath('./p[@class="tem"]/i/text()').extract_first()
            temperature = temperature1 + ' ~ ' + temperature2
            weather_item['temperature'] = temperature
            spanwinds = li.xpath('./p[@class="win"]/em/span')
            spanwind = spanwinds[0]
            wind = spanwind.xpath('./@title').extract_first()
            weather_item['wind'] = wind
            wind_level = li.xpath('./p[@class="win"]/i/text()').extract_first()
            weather_item['wind_level'] = wind_level
            desc_lis = ul.xpath('./li')
            # 紫外线
            ultraviolet_li = desc_lis[0]
            ultraviolet_name = ultraviolet_li.xpath('./em/text()').extract_first()
            weather_item['ultraviolet_name'] = ultraviolet_name
            Ultraviolet_level = ultraviolet_li.xpath('./span/text()').extract_first()
            weather_item['Ultraviolet_level'] = Ultraviolet_level
            Ultraviolet_desc = ultraviolet_li.xpath('./p/text()').extract_first()
            weather_item['Ultraviolet_desc'] = Ultraviolet_desc
            # 穿衣
            dress_li = desc_lis[3]
            dress_name = dress_li.xpath('./a/em/text()').extract_first()
            weather_item['dress_name'] = dress_name
            dress_level = dress_li.xpath('./a/span/text()').extract_first()
            weather_item['dress_level'] = dress_level
            dress_desc = dress_li.xpath('./a/p/text()').extract_first()
            weather_item['dress_desc'] = dress_desc
            # 洗车
            washcar_li = desc_lis[4]
            washcar_name = washcar_li.xpath('./em/text()').extract_first()
            weather_item['washcar_name'] = washcar_name
            washcar_level = washcar_li.xpath('./span/text()').extract_first()
            weather_item['washcar_level'] = washcar_level
            washcar_desc = washcar_li.xpath('./p/text()').extract_first()
            weather_item['washcar_desc'] = washcar_desc
            # 污染
            airpollution_li = desc_lis[5]
            airpollution_name = airpollution_li.xpath('./em/text()').extract_first()
            weather_item['airpollution_name'] = airpollution_name
            airpollution_level = airpollution_li.xpath('./span/text()').extract_first()
            weather_item['airpollution_level'] = airpollution_level
            airpollution_desc = airpollution_li.xpath('./p/text()').extract_first()
            weather_item['airpollution_desc'] = airpollution_desc
            weather_item['city'] = response.meta['city']
            yield weather_item












