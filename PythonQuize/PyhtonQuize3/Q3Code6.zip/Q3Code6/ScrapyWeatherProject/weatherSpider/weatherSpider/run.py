from scrapy import cmdline
cmdline.execute("scrapy crawl weatherSpider".split())
