# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

from scrapy_djangoitem import DjangoItem
from weatherApp.models import Province_info
from weatherApp.models import City_info
from weatherApp.models import weather_info


class WeatherProvinceItem(DjangoItem):
    django_model = Province_info


class WeatherCityItem(DjangoItem):
    django_model = City_info


class WeatherDayStatusItem(DjangoItem):
    django_model = weather_info
