import requests
import sys
from bs4 import BeautifulSoup

# !/usr/bin/env python3
# -*- coding: utf-8 -*
# 没有header报错没有权限访问
# weather_url = 'http://www.weather.com.cn/textFC/hb.shtml'
urls = ['http://www.weather.com.cn/textFC/hb.shtml',
        'http://www.weather.com.cn/textFC/db.shtml',
        'http://www.weather.com.cn/textFC/hd.shtml',
        'http://www.weather.com.cn/textFC/hz.shtml',
        'http://www.weather.com.cn/textFC/hn.shtml',
        'http://www.weather.com.cn/textFC/xb.shtml',
        'http://www.weather.com.cn/textFC/xn.shtml']
# urls = ['http://www.weather.com.cn/textFC/hb.shtml']


def getWeatherData(weather_url: str):
    global city_size, table_list5, a__text, td_item
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36"
    }
    # 请求
    response = requests.get(url=weather_url, headers=headers)
    text = response.content.decode('utf-8')
    # print(text)
    # 解析
    bf = BeautifulSoup(text)
    div_city = bf.find('div', class_='lQCity')
    city_list = div_city.find_all('li')
    city_size = len(city_list)
    print(f'总共多少个省份:{city_size}')
    # 获取重要元素
    table_list = bf.find_all('table')
    table_list5 = [];
    for table_index in range(len(table_list)):
        if table_index < city_size:
            table_list5.append(table_list[table_index])
    # print(f'tr_list: {tr_list}')
    # print(f'table_list5: {table_list5}')
    print(f'table_list5的个数: {len(table_list5)}')
    citys_data = []

    for table_item in table_list5:

        tr_list = table_item.find_all('tr')

        for tr_index in range(len(tr_list)):
            item = tr_list[tr_index]
            # print(tr_index)
            if tr_index >= 2:
                print("-------------------------" * 3)

                td_list = item.find_all('td')
                # print(td_list)
                city_data = []
                for td_index in range(len(td_list)):

                    td_item = td_list[td_index]
                    # print(f'td_item:  {td_item}')
                    # print(f'td_index:  {td_index}')
                    if td_index == 1:
                        if tr_index > 2:
                            td_item = td_list[td_index - 1]
                        a__text = td_item.find('a').text
                        print(f'城市:{a__text}')
                        city_data.append(a__text + '\u3000')
                    if td_index == 2:
                        if tr_index > 2:
                            td_item = td_list[td_index - 1]
                        print(f'白天天气:{td_item.text}')
                        city_data.append(td_item.text + '\u3000')
                    if td_index == 4:
                        if tr_index > 2:
                            td_item = td_list[td_index - 1]
                        print(f'最高气温:{td_item.text}')
                        city_data.append(td_item.text + '\u3000')
                    if td_index == 5:
                        if tr_index > 2:
                            td_item = td_list[td_index - 1]
                        print(f'夜间天气:{td_item.text}')
                        city_data.append(td_item.text + '\u3000')
                    if td_index == 7:
                        if (tr_index > 2):
                            td_item = td_list[td_index - 1]
                        print(f'最低气温:{td_item.text}')
                        city_data.append(td_item.text + '\u3000')
                print(f'city_data{city_data}')
                citys_data.append(city_data)
                print(f'citys_data{citys_data}')

    return citys_data


titles = ['城市', '白天天气', '最高气温', '夜间天气', '最低气温']

file = open('weather_data.txt', 'w')
for title_item in titles:
    file.write(title_item + '\u3000')

for url in urls:
    print("***********" * 3)
    data = getWeatherData(url)
    file.write('\n')
    for item in data:
        print(item)

        for item1 in item:
            file.write(item1)

        file.write('\n')
