import xlwt


class write_file(data):
    book = xlwt.Workbook(encoding='utf-8') # 创建Workbook，相当于创建Excel

    # 创建sheet，Sheet1为表的名字，cell_overwrite_ok为是否覆盖单元格
    sheet1 = book.add_sheet('data')

    data = (
            ["姓名", "语文", "数学", "英语"],
            ["张三", 130, 120, 100],
            ["李四", 100, 110, 120],
            ["王五", 125, 135, 135]
    )

    r = 0

    for i, j in enumerate(data):   # i表示data中的key，j表示data中的value
        le = len(j)   # values返回的列表长度
        # if r == 0:
        #     sheet1.write(r, 0, i, set_style('Arial', 220, True)) #添加第 0 行 0 列数据单元格背景设为黄色
        # else:
        #     sheet1.write(r, 0, i, )  # 添加第 1 列的数据

        for c in range(0, le + 1):  # values列表中索引
            if r == 0:
                sheet1.write(r, c, j[c - 1], set_style('Arial', 220, True))  # 添加第 0 行，2 列到第 5 列的数据单元格背景设为黄色
            else:
                sheet1.write(r, c, j[c - 1])

        r += 1  # 行数

    # sheet_merge() 合并单元格
    book.save('write.xls')


def set_style(name, height, bold):

    style = xlwt.XFStyle()   # 初始化样式

    font = xlwt.Font()   # 创建字体, Font定义字体的大小、颜色
    font.name = name     # 字体名称
    font.bold = bold     # 粗体
    # font.italic = True # 斜体
    font.height = height  # 字体大小
    # font.colour_index = 4  # 字体颜色

    borders = xlwt.Borders()  # 单元格边框线
    borders.left = xlwt.Borders.THIN   # 设置边框线粗细
    borders.right = xlwt.Borders.THIN
    borders.top = xlwt.Borders.THIN
    borders.bottom = xlwt.Borders.THIN
    # borders.right_colour = 1  #设置边框线颜色
    # borders.left_colour = 1
    # borders.top_colour = 1
    # borders.bottom_colour = 1

    alignment = xlwt.Alignment()  # 设置字体在单元格中的位置
    alignment.horz = xlwt.Alignment.HORZ_CENTER  # 水平居左
    alignment.vert = xlwt.Alignment.VERT_CENTER  # 垂直居中

    pat = xlwt.Pattern()  # 设置单元格背景颜色
    pat.pattern = xlwt.Pattern.SOLID_PATTERN
    pat.pattern_fore_colour = 5   # 黄色

    style.font = font
    style.borders = borders
    style.alignment = alignment
    style.pattern = pat

    return style