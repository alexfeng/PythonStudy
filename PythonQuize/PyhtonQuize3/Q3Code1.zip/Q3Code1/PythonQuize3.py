import pymysql
import requests
from bs4 import BeautifulSoup


def db_weather_create():
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "123456", "test_python")
    # 使用 cursor() 方法创建一个游标对象 cursor
    cursor = db.cursor()

    # 使用 execute() 方法执行 SQL，如果表存在则删除
    cursor.execute("DROP TABLE IF EXISTS tb_weather")

    # 使用预处理语句创建表
    sql = """CREATE TABLE tb_weather (
      id bigint(32) NOT NULL AUTO_INCREMENT COMMENT 'ID',
      city varchar(50) NOT NULL COMMENT '城市',
      am_weather varchar(50) DEFAULT NULL COMMENT 'am天气现象',
      am_wind varchar(50) DEFAULT NULL COMMENT 'am风向',
      am_temperature  varchar(50) DEFAULT NULL COMMENT 'am温度',
      pm_weather varchar(50) DEFAULT NULL COMMENT 'pm天气现象',
      pm_wind varchar(500) DEFAULT NULL COMMENT 'pm风向',
      pm_temperature INT DEFAULT NULL COMMENT 'pm温度',
      PRIMARY KEY (`id`)
    )ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8"""
    cursor.execute(sql)
    db.close()


def db_weather_insert(a, b, c, d, e, f, g):
    db = pymysql.connect("localhost", "root", "123456", "test_python")
    cursor = db.cursor()
    sql = "INSERT INTO tb_weather(city, am_weather, am_wind, am_temperature, pm_weather, pm_wind, pm_temperature)VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (
        a, b, c, d, e, f, g)
    try:
        cursor.execute(sql)
        db.commit()
    except:
        # 如果发生错误则回滚
        db.rollback()
    db.close()


def db_weather_select(name):
    db = pymysql.connect("localhost", "root", "123456", "test_python")
    cursor = db.cursor()
    try:
        cursor.execute('SELECT * FROM tb_weather where city = %s', name)
        results = cursor.fetchall()
        for row in results:
            # 打印结果
            print("城市：%s & 白天：天气现象：%s & 白天：风向风力：%s & 白天：最高气温：%s & 夜间：天气现象：%s & 夜间：风向风力：%s & 夜间：最低气温：%s" % (row[1], row[2], row[3], row[4], row[5], row[6], row[7]))
    except:
        print("Error: unable to fetch data")
    db.close()


def parse_page(url):
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36"
    }
    response = requests.get(url, headers=headers)
    text = response.content.decode('utf-8')
    soup = BeautifulSoup(text, 'html.parser')
    conMidtab = soup.find('div', class_='conMidtab')
    tables = conMidtab.find_all('table')
    for table in tables:
        trs = table.find_all('tr')[2:]
        for index, tr in enumerate(trs):
            tds = tr.find_all('td')
            city_td = tds[0]
            if index == 0:
                city_td = tds[1]
            city = list(city_td.stripped_strings)[0]

            if city == "省/直辖市":
                continue
            if city == "天气现象":
                continue

            tb_temp2 = list(tds[-2].stripped_strings)[0]

            spans3 = tds[-3].find_all('span')
            tb_temp3 = list(spans3[0].stripped_strings)[0]
            tb_temp33 = list(spans3[1].stripped_strings)[0]

            tb_temp4 = list(tds[-4].stripped_strings)[0]
            tb_temp5 = list(tds[-5].stripped_strings)[0]

            spans6 = tds[-6].find_all('span')
            tb_temp6 = list(spans6[0].stripped_strings)[0]
            tb_temp66 = list(spans6[1].stripped_strings)[0]

            tb_temp7 = list(tds[-7].stripped_strings)[0]

            db_weather_insert(city, tb_temp7, tb_temp6+tb_temp66, tb_temp5, tb_temp4, tb_temp3+tb_temp33, tb_temp2)

            print({'城市': city, '白天：天气现象': tb_temp7, '白天：风向风力': (tb_temp6+tb_temp66), '白天：最高气温': tb_temp5, '夜间：天气现象': tb_temp4, '夜间：风向风力PM': (tb_temp3+tb_temp33), '夜间：最低气温': tb_temp2})


def main():
    urls = {
        'http://www.weather.com.cn/textFC/hb.shtml',
        'http://www.weather.com.cn/textFC/db.shtml',
        'http://www.weather.com.cn/textFC/hd.shtml',
        'http://www.weather.com.cn/textFC/hz.shtml',
        'http://www.weather.com.cn/textFC/hn.shtml',
        'http://www.weather.com.cn/textFC/xb.shtml',
        'http://www.weather.com.cn/textFC/xn.shtml',
        'http://www.weather.com.cn/textFC/gat.shtml'
    }
    for url in urls:
        parse_page(url)


if __name__ == "__main__":
    db_weather_create()
    main()

    while True:
        print('++++++++++++++++++++++++++++++++++')
        city_name = input("请输入你要查询的城市名字：")
        db_weather_select(city_name)

