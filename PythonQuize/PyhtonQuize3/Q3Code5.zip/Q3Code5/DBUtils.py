import pymysql
from dbconfig import dbinfo

class DBUtils:
    def __init__(self,
                 host=dbinfo['host'],
                 port=dbinfo['port'],
                 user=dbinfo['user'],
                 password=dbinfo['password'],
                 db=dbinfo['db']):
        self.host = host,
        self.port = port,
        self.user = user,
        self.password = password,
        self.db = db,
        self.conn = None
        self.cursor = None

    # 连接数据库
    def getConnection(self):
        if not self.db:
            raise RuntimeError('配置信息错误')
            return False

        try:
            self.conn = pymysql.connect(host=list(self.host)[0], port=list(self.port)[0], user=list(self.user)[0],
                                        password=list(self.password)[0], db=list(self.db)[0])
            # self.conn = pymysql.connect('localhost','root', 'root', 'spiderdb')
        except:
            raise RuntimeError('初始化数据库失败')
            return False

        self.cursor = self.conn.cursor()
        return True

    # 关闭数据库
    def close(self):
        # 如果数据打开，则关闭；否则没有操作
        if self.conn and self.cursor:
            self.cursor.close()
            self.conn.close()
        return True

    # 执行数据库的sq语句,主要用来做插入操作
    def execute(self, sql, params=None):
        # 连接数据库
        self.getConnection()
        try:
            if self.conn and self.cursor:
                # 正常逻辑，执行sql，提交操作
                self.cursor.execute(sql, params)
                self.conn.commit()
        except:
            self.close()
            return False
        return True

    # 执行数据库的sq语句,批量执行
    def executemany(self, sql, params=None):
        # 连接数据库
        self.getConnection()
        try:
            if self.conn and self.cursor:
                # 正常逻辑，执行sql，提交操作
                self.cursor.executemany(sql, params)
                self.conn.commit()
        except:
            self.close()
            return False
        return True

    # 用来查询表数据
    def fetchall(self, sql, params=None):
        self.execute(sql, params)
        return self.cursor.fetchall()


