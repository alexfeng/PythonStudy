import requests
import datetime
from bs4 import BeautifulSoup
from DBUtils import DBUtils

#获取天气网站数据
def get_allWeatherData():
    targetURL = "http://www.nmc.cn/publish/forecast/china.html#"
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36"}

    req = requests.get(targetURL, headers=headers, timeout=30)
    # 设置页面编码格式
    req.encoding = "utf-8"
    soup = BeautifulSoup(req.text, features="html.parser")

    allArea = soup.find(id="areaContent").find_all('div', class_='area')
    data = []
    for area in allArea:
        arealist = area.select("ul")[0].select("li")
        for areaWeather in arealist:
            weather = dict()
            weather['name'] = areaWeather.find_all('div', class_='cname')[0].select("a")[0].get_text().strip()
            weather['url'] = areaWeather.find_all('div', class_='cname')[0].select("a")[0].get("href").strip()
            weather['tianqi'] = areaWeather.find_all('div', class_='weather')[0].get_text().strip()
            weather['wendu'] = areaWeather.find_all('div', class_='temp')[0].get_text().strip()
            data.append(weather)
    return data

#保存数据
def comment_db(data):
    dbUtils=DBUtils()
    # 删除已存在的表
    dbUtils.execute("DROP TABLE IF EXISTS weather_data", None)
    #创建表
    dbUtils.execute("""CREATE TABLE weather_data (
            id bigint(11) NOT NULL AUTO_INCREMENT,
            name varchar(255) DEFAULT NULL,
            tianqi varchar(255) DEFAULT NULL,
            wendu varchar(255) DEFAULT NULL,
            url varchar(255) DEFAULT NULL,
            sdate varchar(255) DEFAULT NULL,
            PRIMARY KEY (id)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;""", None)

    #保存数据
    sql = "insert into weather_data(name, url, tianqi, wendu, sdate) values(%s,%s,%s,%s,%s)"
    sdate = datetime.datetime.now().strftime('%Y-%m-%d')
    insterData=[]
    for weather in data:
        insterData.append((weather['name'], 'http://www.nmc.cn' + weather['url'], weather['tianqi'], weather['wendu'], sdate))

    dbUtils.executemany(sql,tuple(insterData))
    return True


#获取天气网站数据
# weatcherData=get_allWeatcherData()
#保存数据
# comment_db(weatcherData)