# -*- coding: utf-8 -*-

import web
from DBUtils import DBUtils
import PaTianQi


render = web.template.render('templates/')

urls = (
    '/gendata', 'gendata',
    '/querydata', 'querydata',
    '/queryAlldata', 'queryAlldata',
    '/(.*)', 'index'
)

#默认打开index页面
class index:
    def GET(self,name):
        return render.index()

#抓取数据并保存到数据库
class gendata:
    def GET(self):
        # 获取天气网站数据
        weatherData = PaTianQi.get_allWeatherData()
        # 保存数据
        PaTianQi.comment_db(weatherData)
        return render.index()
#全量查询数据
class queryAlldata:
    def GET(self):
        dbUtils = DBUtils()

        sql = "select * from weather_data"
        rows = dbUtils.fetchall(sql,None)

        return render.weather(rows)

#按城市名称查询数据
class querydata:
    def POST(self):
        data = web.input()

        dbUtils = DBUtils()
        sql = "select * from weather_data where name = %s"
        rows=dbUtils.fetchall(sql, data.area)
        return render.weather(rows)

if __name__ == "__main__":
    app = web.application(urls, globals())
    app.run()


