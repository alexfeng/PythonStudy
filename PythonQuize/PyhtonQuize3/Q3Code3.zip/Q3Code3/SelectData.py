#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import sqlite3
from tkinter import *

rootdir = "/Users/xjliu/Music/PycharmProjects/pythonExams/src/PythonQuize3/data/"


def show():
    root = Tk()
    root.title("天气查询")  # 在这里修改窗口的标题
    Label(root, text='', ).grid(row=1)
    Label(root, text='', ).grid(row=2)
    Label(root, text='省份名称 :').grid(row=3, column=0)  # 对Label内容进行 表格式 布局
    Label(root, text='城市名称 :').grid(row=4, column=0)
    v1 = StringVar()  # 设置变量 .
    v2 = StringVar()
    e1 = Entry(root, textvariable=v1)  # 用于储存 输入的内容
    e2 = Entry(root, textvariable=v2)
    e1.grid(row=3, column=1, padx=10, pady=5)  # 进行表格式布局 .
    e2.grid(row=4, column=1, padx=10, pady=5)
    Button(root, text='查询', width=10, command=lambda: hellocallback(root, e1.get(), e2.get())).grid(row=5, column=0,
                                                                                                    sticky=W, padx=10,
                                                                                                    pady=5)  # 设置 button 指定 宽度 , 并且 关联 函数 , 使用表格式布局 .
    Button(root, text='退出', width=10, command=root.quit).grid(row=5, column=1, sticky=E, padx=10, pady=5)
    Label(root, text='', ).grid(row=6)

    root.mainloop()


def hellocallback(root, provice, city):
    cursor = select(provice, city)
    row = cursor.fetchone();
    Label(root, text='白天', ).grid(row=7, column=0)
    Label(root, text='天气状况:' + row[2], ).grid(row=8, column=0)
    Label(root, text='风力方向:' + row[3], ).grid(row=9, column=0)
    Label(root, text='最高温度:' + row[4], ).grid(row=10, column=0)
    Label(root, text='夜间', ).grid(row=7, column=1)
    Label(root, text='天气状况:' + row[5], ).grid(row=8, column=1)
    Label(root, text='风力方向:' + row[6], ).grid(row=9, column=1)
    Label(root, text='最低温度:' + row[7], ).grid(row=10, column=1)
    Label(root, text='', ).grid(row=11)
    Label(root, text='', ).grid(row=12)


def select(provice, city):
    """
    根据不同的条件查找数据
    当用户名和密码都正确时, 查询数据
    """
    conn = sqlite3.connect(rootdir + 'data_weather.db')
    sql_select = '''SELECT  provice, city,am_weather,am_wind,am_max,pm_weather,pm_wind,pm_min FROM    weatherinfo
    WHERE  provice=? and city=?
             '''
    cursor = conn.execute(sql_select, (provice, city))
    return cursor


if __name__ == '__main__':
    show()
