#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import sqlite3
import time
from idlelib.multicall import r

import requests
from bs4 import BeautifulSoup

from src.PythonQuize3.headers import FakeChromeUA

rootdir = "/Users/xjliu/Music/PycharmProjects/pythonExams/src/PythonQuize3/data/"

requests.adapters.DEFAULT_RETRIES = 5  # 增加重连次数
proxys = {"http": "http://" + "116.196.90.181:3128",
          "https": "https://" + "60.217.157.112:8060",
          "https": "https://" + '118.89.216.43:8888',
          "https": "https://" + '106.52.76.227:808',
          "https": "https://" + '47.94.224.106:8000',
          "https": "https://" + '125.110.124.231:9000',
          "https": "https://" + '58.254.220.116:53579',
          "https": "https://" + '117.87.177.161:9000',
          "https": "https://" + '112.111.117.44:9000',
          "https": "https://" + '27.188.72.54:8060'}

headers = {
    'Connection': 'close',
    'User-Agent': FakeChromeUA.get_ua(),
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}


def getprovice(url):
    conn = sqlite3.connect(rootdir + 'data_weather.db')
    session = requests.session()
    session.keep_alive = False  # 关闭多余连接
    try:
        response = requests.get(url, headers=headers, proxies=proxys).content  # 提交requests get 请求
        soup = BeautifulSoup(response, features="html.parser")  # 用Beautifulsoup 进行解析
        divs = soup.find('div', class_='wdetail')
        tables = divs.findAll('table')
        for index, tr in enumerate(tables[1].find_all('tr')):
            td_list = tr.find_all('td')
            for td in td_list:
                getcity(conn, td.text, url, td.a.get('href'))
    except requests.exceptions.ConnectionError:
        r.status_code = "Connection refused"
        print('Connection refused1')
        time.sleep(2)


def getcity(conn, provice, rooturl, url):
    session = requests.session()
    session.keep_alive = False  # 关闭多余连接
    try:
        response = requests.get(rooturl + url, headers=headers, proxies=proxys).content  # 提交requests get 请求
        soup = BeautifulSoup(response, features="html.parser")  # 用Beautifulsoup 进行解析
        divs = soup.find('div', class_='wdetail')
        tables = divs.findAll('table')
        tr_list = tables[0].find_all('tr')[1:]  # 使用切片取到第三个tr标签
        # lamd = lambda x: x[:2] if len(x) >= 2 else x
        for index, tr in enumerate(tr_list):
            td_list = tr.find_all('td')
            for city in td_list:
                getweather(conn, provice, city.text, rooturl + 'weather/', city.a.get('href'))
                time.sleep(1)

    except requests.exceptions.ConnectionError:
        r.status_code = "Connection refused"
        print('Connection refused2')
        time.sleep(2)


def getweather(conn, provice, city, rooturl, url):
    session = requests.session()
    session.keep_alive = False  # 关闭多余连接
    try:
        session = session.get(rooturl + url, headers=headers, proxies=proxys)
        session.encoding = 'utf-8'
        response = session.content  # 提交requests get 请求
        soup = BeautifulSoup(response, features="html.parser")  # 用Beautifulsoup 进行解析
        divs = soup.find('div', class_='wdetail')
        tables = divs.findAll('table')
        tr_list = tables[0].find_all('tr')  # 使用切片取到第三个tr标签
        if len(tr_list) > 2:
            # # 取一个月
            # tr_list=tr_list[2:]
            # for index, tr in enumerate(tr_list):
            #     td_list = tr.find_all('td')
            # 只取当天
            tr = tr_list[2]
            td_list = tr.find_all('td')
            am_weather = td_list[2].text
            am_wind = td_list[3].text
            am_max = td_list[4].text
            pm_weather = td_list[5].text
            pm_wind = td_list[6].text
            pm_min = td_list[7].text
            update(conn, provice, city, am_weather, am_wind, am_max, pm_weather, pm_wind, pm_min)
    except requests.exceptions.ConnectionError:
        r.status_code = "Connection refused"
        print('Connection refused3')
        time.sleep(2)


def initDatabase():
    conn = sqlite3.connect(rootdir + 'data_weather.db')
    create(conn)
    conn.commit()
    conn.close()


def create(conn):
    # 创建相应的数据表
    sql_create = '''
 CREATE TABLE IF NOT EXISTS weatherinfo (provice text,city text,am_weather text,am_wind text,am_max text,
 pm_weather text,pm_wind text,pm_min text)
    '''
    # 用 execute 执行一条 sql 语句
    conn.execute(sql_create)
    print('创建成功')


def update(conn, provice, city, am_weather, am_wind, am_max, pm_weather, pm_wind, pm_min):
    sql_update = '''INSERT INTO weatherinfo(provice,city,am_weather,am_wind,am_max,pm_weather,pm_wind,pm_min) VALUES (?, ?, ?,?,?, ?, ?,?)
          '''
    conn.execute(
        sql_update, (
            provice, city, am_weather, am_wind, am_max, pm_weather, pm_wind, pm_min
        ))
    conn.commit()


def select(provice, city):
    """
    根据不同的条件查找数据
    当用户名和密码都正确时, 查询数据
    """
    conn = sqlite3.connect(rootdir + 'data_weather.db')
    sql_select = '''SELECT  provice, city,am_weather,am_wind,am_max,pm_weather,pm_wind,pm_min FROM    weatherinfo
    WHERE  provice=? and city=?
             '''
    cursor = conn.execute(sql_select, (provice, city))
    return cursor


def delete(conn, provice, city):
    """
    根据 id 删除对应的那条数据
    """
    sql_delte = '''
    DELETE FROM
      weatherinfo
       WHERE  provice=? and city=?
    '''
    # tuple 只有一个元素的时候必须是这种写法
    conn.execute(sql_delte, (provice, city))


if __name__ == '__main__':
    initDatabase()
    # 天气后报
    getprovice('http://www.tianqihoubao.com/')
